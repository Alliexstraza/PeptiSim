# [Overview](@id classes-overview)

The data members of fundamental classes in HiGHS are defined in this section.

 * [HighsSparseMatrix](@ref)
 * [HighsLp](@ref)
 * [HighsHessian](@ref)
 * [HighsModel](@ref)

Class data members for internal use only are not documented.
