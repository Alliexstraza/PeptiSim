#ifndef IPX_CONFIG_H_
#define IPX_CONFIG_H_

#include <stdint.h>

#include "util/HighsInt.h"
typedef HighsInt ipxint;

#endif /* IPX_CONFIG_H_ */
